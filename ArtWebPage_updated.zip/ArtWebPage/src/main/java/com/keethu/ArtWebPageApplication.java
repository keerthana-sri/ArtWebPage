package com.keethu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtWebPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtWebPageApplication.class, args);
	}

}
