package com.keethu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtWebPageApplicationTests {

	@Test
	void contextLoads() {
	}

}
